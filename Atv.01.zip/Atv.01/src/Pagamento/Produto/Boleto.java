package Pagamento.Produto;

public class Boleto {
    public void processarPagamento() {
        System.out.println("Pagando com boleto...");
    }
}
