package Pagamento.Produto;

public class Paypal {
    public void processarPagamento() {
        System.out.println("Pagando com Paypal...");
    }
}
