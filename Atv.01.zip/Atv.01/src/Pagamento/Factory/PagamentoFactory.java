package Pagamento.Factory;

public abstract class PagamentoFactory {
    public abstract void processarPagamento();
}
