package Pagamento;

public class App {
    public interface Pagamento {
        void processarPagamento();
    }
}
